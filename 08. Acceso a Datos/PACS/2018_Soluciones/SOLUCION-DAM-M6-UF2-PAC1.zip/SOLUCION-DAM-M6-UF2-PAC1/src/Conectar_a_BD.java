import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Date;

public class Conectar_a_BD {

	    /* Definir variables privadas para establecer la conexi�n con la base de datos DEPT1 usando usuario "empleado"
	     * y contrase�a "empleado" */
		private static String usuario="empleado";
		private static String contrase�a="empleado";
		private static String bbdd="dept1"; /* Nombre de la base de datos */
		private static String url="jdbc:mysql://localhost/"+bbdd+"?useSSL=false"; /* useSSL=false para evitar warnings en pantalla */
		private static String driver="com.mysql.jdbc.Driver";
		private static Connection conn=null;
		
		/*Funci�n para establecer conexi�n con la base de datos mysql llamada DEPT1 (ejercicio 2)*/
		public Connection establecer_conexion(){
			
			try{
				Class.forName(driver);
				conn=DriverManager.getConnection(url,usuario,contrase�a);
				System.out.println("\n\nConexi�n a base de datos DEPT1 realizada correctamente");
				limpiar_tablas(); /* Limpiar datos previos en las tablas DEPARTAMENTOS y EMPLEADOS */
			}
			catch(ClassNotFoundException | SQLException ex){
				System.out.println("ERROR al intentarse conectar a la base de datos");
			}
			return conn;
		}
		
		public void limpiar_tablas(){
			/* Esta funci�n borra existentes registros de las tablas DEPARTAMENTOS y EMPLEADOS */
			try{
				Statement setencia_sql=conn.createStatement();
				int rst=setencia_sql.executeUpdate("SET FOREIGN_KEY_CHECKS = 0;"); /* Hay que desactivar las FOREIGN KEYS para poder limpiar tablas*/
				rst=setencia_sql.executeUpdate("TRUNCATE dept1.DEPARTAMENTOS;"); /* Vaciar tabla DEPARTAMENTOS */
				rst=setencia_sql.executeUpdate("TRUNCATE dept1.EMPLEADOS;"); /* Vaciar tabla EMPLEADOS */
				rst=setencia_sql.executeUpdate("SET FOREIGN_KEY_CHECKS = 1;"); /* Volver a activar las FOREIGN KEYS para poder limpiar tablas*/
				setencia_sql.close();
				System.out.println("Si estaban llenas, las tablas DEPARTAMENTOS y EMPLEADOS han sido vaciadas\n");
			}
			catch(SQLException ex){
				System.out.println("ERROR al intentar limpiar tablas de datos existentes");
			}
		}
		
		/*Implementaci�n de funci�n para introducir datos en la tabla DEPARTAMENTOS (ejercicio 3)*/
		public boolean a�adir_departamento (int dept_no, String dept_nombre, String lugar){
				try{
					Statement setencia_sql=conn.createStatement();
					String linea_sentencia_sql="INSERT INTO DEPARTAMENTOS VALUES ("+dept_no+",'"+dept_nombre+"','"+lugar+"');";
					int rst=0;
					rst=setencia_sql.executeUpdate(linea_sentencia_sql);
					setencia_sql.close();
					System.out.println("Insertado departamento "+dept_no+": "+dept_nombre);
					if(rst>0){
						return true;
					}
					else {
						return false;
					}
					
				}catch(SQLException ex){
					System.out.println("ERROR: no se ha podido registrar el departamento "+dept_no+"|"+dept_nombre+"|"+lugar);
					return false;
				}
		}
		
		/* Implementaci�n de funci�n para introducir datos en las tablas EMPLEADOS (ejercicio 3)*/
		public boolean a�adir_empleado (int emp_no, String apellido, String oficio, int jefe, String fecha, int salario, int comision, int dept_no){
				try{
					Statement setencia_sql=conn.createStatement();
					String linea_sentencia_sql="INSERT INTO EMPLEADOS VALUES ("+emp_no+",'"+apellido+"','"+oficio+"',"+jefe+",'"+fecha+"',"+salario+","+comision+","+dept_no+");";
					int rst=0;
					rst=setencia_sql.executeUpdate(linea_sentencia_sql);
					setencia_sql.close();
					System.out.println("Empleado "+apellido+" registrado en departamento "+dept_no);
					if(rst>0){
						return true;
					}
					else {
						return false;
					}
					
				}catch(SQLException ex){
					System.out.println("ERROR: no se ha podido almacenar los datos");
					return false;
				}
		}
		
		
		/*Implementaci�n de funci�n para comprobar si los valores num�ricos introducidos son todos positivos (ejercicio 4)*/
		public static boolean comprobar_valores_positivos(int emp_no, int jefe, int salario, int comision, int dept_no){
			try{
				Statement setencia_sql=conn.createStatement();
				boolean esPositivo=false;
				if(emp_no<0){
					System.out.println(" ERROR al intentar registrar nuevo empleado: no se puede insertar un valor negativo para el n�mero de empleado");
					esPositivo=false;
				}
				else if(jefe<0){
					System.out.println(" ERROR al intentar registrar nuevo empleado: no se puede insertar un valor negativo para el n�mero de jefe");
					esPositivo=false;
				}
				else if(salario<0){
					System.out.println(" ERROR al intentar registrar nuevo empleado: no se puede insertar un valor negativo para el salario");
					esPositivo=false;
				}
				else if(comision<0){
					System.out.println(" ERROR al intentar registrar nuevo empleado: no se puede insertar un valor negativo para la comision");
					esPositivo=false;
				}
				else if(dept_no<0){
					System.out.println(" ERROR al intentar registrar nuevo empleado: no se puede insertar un valor negativo para el n�mero de departamento");
					esPositivo=false;
				}
				else{
					esPositivo=true;
				}
				setencia_sql.close();
				return esPositivo;
			}catch (SQLException ex){
				System.out.println(" ERROR al intentar registrar nuevo empleado: no se ha podido comprobar los datos introducidos");
				return false;
			}
		}

		/*Implementaci�n de funci�n para comprobar si el emp_no ya ha sido dado (ejercicio 4)*/
		public static boolean validar_emp_no(int emp_no){
			try{
				Statement setencia_sql=conn.createStatement();
				boolean existe_emp_no=false;
				String linea_sentencia_sql="SELECT * FROM EMPLEADOS WHERE EMP_NO="+emp_no+";";
				ResultSet rst=setencia_sql.executeQuery(linea_sentencia_sql);
				rst.last();
				if(rst.getRow()>0){
					System.out.println(" ERROR al intentar registrar nuevo empleado: ese emp_no ya ha sido asignado a otro empleado");
					existe_emp_no=true;
				}
				else{
					existe_emp_no=false;
				}	
				setencia_sql.close();
				return existe_emp_no;
			}catch (SQLException ex){
				System.out.println(" ERROR: no se ha podido comprobar los datos introducidos");
				return false;
			}
		}
		
		/*Implementaci�n de funci�n para comprobar que el departamento existe (ejercicio 4)*/
		public static boolean validar_dept_no(int dept_no){
			try{
				Statement setencia_sql=conn.createStatement();
				boolean existe_dept=false;
				String linea_sentencia_sql="SELECT * FROM EMPLEADOS WHERE DEPT_NO="+dept_no+";";
				ResultSet rst=setencia_sql.executeQuery(linea_sentencia_sql);
				rst.last();
				if(rst.getRow()>0){
					existe_dept=true;
				}
				else{
					System.out.println(" ERROR al intentar registrar nuevo empleado: No existe dicho departamento");
					existe_dept=false;
				}	
				setencia_sql.close();
				return existe_dept;
			}catch (SQLException ex){
				System.out.println(" ERROR: no se ha podido comprobar los datos introducidos");
				return false;
			}
		}
		
		/*Implementaci�n de funci�n para comprobar el jefe asignado existe (ejercicio 4)*/
		public static boolean validar_jefe(int jefe){
			try{
				Statement setencia_sql=conn.createStatement();
				boolean existe_jefe=false;
				String linea_sentencia_sql="SELECT * FROM EMPLEADOS WHERE JEFE="+jefe+";";
				ResultSet rst=setencia_sql.executeQuery(linea_sentencia_sql);
				rst.last();
				if(rst.getRow()>0){
					existe_jefe=true;
				}
				else{
					System.out.println(" ERROR al intentar registrar nuevo empleado: no existe jefe asignado");
					existe_jefe=false;
				}	
				setencia_sql.close();
				return existe_jefe;
			}catch (SQLException ex){
				System.out.println(" ERROR al intentar registrar nuevo empleado: no se ha podido comprobar los datos introducidos");
				return false;
			}
		}
			
		/*Si el registro del empleado es v�lido, inserta un nuevo dato en la tabla EMPLEADOS (ejercicio 4)*/
		public boolean insertar_nuevo_empleado(int emp_no, String apellido, String oficio, int jefe, String fecha, int salario, int comision, int dept_no){

			if(!validar_emp_no(emp_no) && comprobar_valores_positivos(emp_no, jefe, salario, comision, dept_no) && validar_dept_no(dept_no) && validar_jefe(jefe)){
				try{
					Statement setencia_sql=conn.createStatement();
					boolean existe=false;
					String linea_sentencia_sql="INSERT INTO EMPLEADOS VALUES ("+emp_no+",'"+apellido+"','"+oficio+"',"+jefe+",'"+fecha+"',"+salario+","+comision+","+dept_no+");";
					int rst=setencia_sql.executeUpdate(linea_sentencia_sql);
					if(rst>0){
						System.out.println(" CONSEGUIDO: Empleado "+apellido+" registrado en departamento "+dept_no);
						existe=true;
					}
					setencia_sql.close();
					return existe;
				}catch(SQLException e) {
					System.out.println("ERROR: no se ha podido introducir el empleado");
					return false;
				}
			}
			return false;
		}
		
		
		/* Implementaci�n de funci�n en la que se visualiza la tabla EMPLEADOS (ejercicio 5) */
		public void imprimir_tabla_empleados(){
			try{
				System.out.println("\n\n ***********TABLA EMPLEADOS***********\n");
				System.out.println("   EMP_NO |   APELLIDO  |     OFICIO   |  JEFE |  FECHA_ALTA  | SALARIO   | COMISI�N   |  DEPT_NO");
				Statement setencia_sql=conn.createStatement();
				String linea_sentencia_sql="SELECT * FROM EMPLEADOS";
				ResultSet rst=setencia_sql.executeQuery(linea_sentencia_sql);
				while(rst.next()){
					int emp_no=rst.getInt("emp_no");	
					String apellido=rst.getString("apellido");
					String oficio=rst.getString("oficio");
					int jefe=rst.getInt("jefe");
					Date fecha=rst.getDate("fecha_alta");
					int salario=rst.getInt("salario");
					int comision=rst.getInt("comision");
					int dept_no=rst.getInt("dept_no");
					System.out.format("   %6d | %10s  |  %10s  |  %4d |  %s  |  %6d   |  %7d   |   %6d \n",emp_no,apellido,oficio,jefe,fecha,salario,comision,dept_no);
				}
				setencia_sql.close();
			}
			catch(SQLException ex){
				System.out.println("ERROR al mostrar los datos de la tabla EMPLEADOS");
			}	
		}
		
		/*Implementaci�n de funci�n para cerrar la conexi�n con la base de datos DEPT (ejercicio 6) */
		public void desconectar_BD(){
			try{
				System.out.println("\n Base de datos DEPT1 desconectada exitosamente!");
				conn.close();
			}
			catch(SQLException ex){
				System.out.println("ERROR al intentar la desconexi�n de la base de datos DEPT1");
			}
		}
}