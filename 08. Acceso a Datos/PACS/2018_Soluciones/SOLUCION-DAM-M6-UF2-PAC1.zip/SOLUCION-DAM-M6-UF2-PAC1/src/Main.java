
public class Main {
	
	/* Este programillo usar� la base de datos SQL llamada DEPT1. Introducir� datos iniciales en tabla EMPLEADOS y luego
	 * introducir� datos adicionales siempre que sean v�lidos */
	
		public static void main (String[]args){
			
			/*Ejecuci�n del ejercicio 2: se crea conexi�n a la base de datos*/
			Conectar_a_BD conectar=new Conectar_a_BD();
			conectar.establecer_conexion();
			
			/*Ejecuci�n del ejercicio 3: Introducimos datos de tabla DEPARTAMENTOS */
			System.out.println("** A�adiendo departamentos en la base de datos **");
			conectar.a�adir_departamento(10, "Contabilidad", "Sevilla");
			conectar.a�adir_departamento(20, "Investigaci�n", "Madrid");
			conectar.a�adir_departamento(40, "Producci�n", "Bilbao");
			conectar.a�adir_departamento(30, "Ventas", "Barcelona");
			System.out.println("\n");
			
			/*Ejecuci�n del ejercicio 3: Introducimos datos iniciales de tabla EMPLEADOS */
			System.out.println("** A�adiendo datos inciales a tabla EMPLEADOS **");
			conectar.a�adir_empleado(7369, "Sanchez", "Empleado", 7902, "1980-12-17", 104000, 0, 20);
			conectar.a�adir_empleado(7499, "Arroyo", "Vendedor", 7698, "1980-02-20", 208000, 39000, 30);
			conectar.a�adir_empleado(7521, "Sala", "Vendedor", 7698, "1981-02-22", 162500, 65000, 30);
			conectar.a�adir_empleado(7566, "Jimenez", "Director", 7839, "1981-04-02", 386750, 0, 20);
			conectar.a�adir_empleado(7654, "Martan", "Vendedor", 7698, "1981-09-29", 162500, 182000, 30);
			conectar.a�adir_empleado(7698, "Negro", "Director", 7839, "1981-05-01", 370500, 0, 30);
			conectar.a�adir_empleado(7782, "Cerezo", "Director", 7839, "1981-06-09", 318500, 0, 10);
			conectar.a�adir_empleado(7788, "Gil", "Analista", 7566, "1981-11-09", 390000, 0, 20);
			conectar.a�adir_empleado(7839, "Rey", "Presidente", 0, "1981-11-17", 650000, 0, 10);
			conectar.a�adir_empleado(7844, "Tovar", "Vendedor", 7698, "1981-09-08", 195000, 0, 30);
			conectar.a�adir_empleado(7876, "Alonso", "Empleado", 7788, "1981-09-23", 143000, 0, 20);
			conectar.a�adir_empleado(7900, "Jimeno", "Empleado", 7698, "1981-12-03", 123500, 0, 30);
			conectar.a�adir_empleado(7902, "Fernandez", "Analista", 7566, "1981-12-03", 390000, 0, 20);
			conectar.a�adir_empleado(7934, "Martinez", "Empleado", 7782, "1982-01-23", 169000, 0, 10);
			System.out.println("\n");
			
			/* Ejecuci�n de ejercicio 4: insertamos nuevos datos en tabla EMPLEADOS siempre que sean v�lidos */
			System.out.println("** A�adiendo nuevos empleados a base de datos **");
			System.out.println("Se intenta insertar nuevo empleado: \n emp_no: -1500, apellido: Sanz, oficio: Empleado, jefe: 7902, fecha_alta: 1985-07-23, salario: 120000, comision: 0, dept_no: 40");
			conectar.insertar_nuevo_empleado(-1500,"Sanz", "Empleado", 7902, "1985-07-23", 120000,0,40);
			System.out.println("Se intenta insertar nuevo empleado: \n emp_no: 7500, apellido: Gonzalez, oficio: Empleado, jefe: 7901, fecha_alta: 1985-07-23, salario: 105000, comision: 0, dept_no: 30");
			conectar.insertar_nuevo_empleado(7500, "Gonzalez", "Empleado", 7901, "1985-07-23", 105000,0,30);
			System.out.println("Se intenta insertar nuevo empleado: \n emp_no: 7650, apellido: Torres, oficio: Empleado, jefe: -7902, fecha_alta: 1985-07-23, salario: 200000, comision: 0, dept_no: 10");
			conectar.insertar_nuevo_empleado(7650, "Torres", "Empleado", -7902, "1985-07-23", 200000,0,10);
			System.out.println("Se intenta insertar nuevo empleado: \n emp_no: 7650, apellido: Iniesta, oficio: Empleado, jefe: 7902, fecha_alta: 1985-07-23, salario: 220000, comision: 0, dept_no: 10");
			conectar.insertar_nuevo_empleado(7844, "Iniesta", "Empleado", 7902, "1985-07-23", 220000,0,10);
			System.out.println("Se intenta insertar nuevo empleado: \n emp_no: 7650, apellido: Torres, oficio: Empleado, jefe: 7902, fecha_alta: 1985-07-23, salario: 150000, comision: 0, dept_no: 10");
			conectar.insertar_nuevo_empleado(7650, "Torres", "Empleado", 7902, "1985-07-23", 150000,0,10);
			
			/*Ejecuci�n de ejercicio 5: Mostramos la tabla EMPLEADOS actual */
			conectar.imprimir_tabla_empleados();
			
			/*Ejercicio 6: Nos desconectamos de la base de datos*/
			conectar.desconectar_BD();
			
		}
}
