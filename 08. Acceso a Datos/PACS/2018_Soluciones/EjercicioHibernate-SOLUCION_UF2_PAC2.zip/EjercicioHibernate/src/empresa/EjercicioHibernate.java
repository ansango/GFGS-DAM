
package empresa;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.*;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class EjercicioHibernate {

      // Propiedades
      private JFrame frmPanelDeGestin;
      private JTextField txtLocalidad;
      private JTextField txtNombre;
      private JTextField txtDepartamento;
      private JLabel lblTitulo = new JLabel("GESTI\u00D3N DE DEPARTAMENTOS");
      // ILERNA: definir variables globales relacionadas con la conexi�n a la base de datos
      private SessionFactory sessionFactory;
      private Session session;
      private Transaction tx;
      private Departamentos d = new Departamentos();
      
      // M�todos
      /**
       * Launch the application.
       */
      public static void main(String[] args) {
            EventQueue.invokeLater(new Runnable() {
                  public void run() {
                        try {
                             EjercicioHibernate window = new EjercicioHibernate();
                             window.frmPanelDeGestin.setVisible(true);
                        } catch (Exception e) {
                             e.printStackTrace();
                        }
                  }
            });
      } // Fin Main

      /**
       * Create the application.
       */
      public EjercicioHibernate() {
            initialize();
      } // Fin Constructor

      /**
       * Initialize the contents of the frame.
       */
      private void initialize() {
            frmPanelDeGestin = new JFrame();
            frmPanelDeGestin.setTitle("Panel de gesti\u00F3n");
            frmPanelDeGestin.setBounds(100, 100, 484, 240);
            frmPanelDeGestin.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frmPanelDeGestin.setLocationRelativeTo(null);
            frmPanelDeGestin.getContentPane().setLayout(null);
           
            lblTitulo.setFont(new Font("Tahoma", Font.BOLD, 14));
            lblTitulo.setBounds(110, 11, 247, 14);
            frmPanelDeGestin.getContentPane().add(lblTitulo);
           
            JLabel lblNDepartamento = new JLabel("N\u00BA de Departamento:");
            lblNDepartamento.setFont(new Font("Tahoma", Font.BOLD, 12));
            lblNDepartamento.setBounds(20, 46, 142, 14);
            frmPanelDeGestin.getContentPane().add(lblNDepartamento);
           
            JLabel lblNombre = new JLabel("Nombre:");
            lblNombre.setFont(new Font("Tahoma", Font.BOLD, 12));
            lblNombre.setBounds(20, 86, 142, 14);
            frmPanelDeGestin.getContentPane().add(lblNombre);
           
            JLabel lblLocalidad = new JLabel("Localidad:");
            lblLocalidad.setFont(new Font("Tahoma", Font.BOLD, 12));
            lblLocalidad.setBounds(21, 125, 142, 14);
            frmPanelDeGestin.getContentPane().add(lblLocalidad);
           
            txtLocalidad = new JTextField();
            txtLocalidad.setHorizontalAlignment(SwingConstants.RIGHT);
            txtLocalidad.setBounds(183, 123, 229, 20);
            frmPanelDeGestin.getContentPane().add(txtLocalidad);
            txtLocalidad.setColumns(10);
           
            txtNombre = new JTextField();
            txtNombre.setHorizontalAlignment(SwingConstants.RIGHT);
            txtNombre.setColumns(10);
            txtNombre.setBounds(183, 84, 229, 20);
            frmPanelDeGestin.getContentPane().add(txtNombre);
           
            txtDepartamento = new JTextField();
            txtDepartamento.setHorizontalAlignment(SwingConstants.RIGHT);
            txtDepartamento.setColumns(10);
            txtDepartamento.setBounds(296, 44, 116, 20);
            frmPanelDeGestin.getContentPane().add(txtDepartamento);
           
            JButton btnAlta = new JButton("Alta");
            btnAlta.addActionListener(new ActionListener() {
                  public void actionPerformed(ActionEvent arg0) {
                        alta();
                  }
            });
            btnAlta.setFont(new Font("Tahoma", Font.BOLD, 12));
            btnAlta.setBounds(17, 165, 89, 23);
            frmPanelDeGestin.getContentPane().add(btnAlta);
           
            JButton btnBaja = new JButton("Baja");
            btnBaja.addActionListener(new ActionListener() {
                  public void actionPerformed(ActionEvent arg0) {
                        baja();
                  }
            });
            btnBaja.setFont(new Font("Tahoma", Font.BOLD, 12));
            btnBaja.setBounds(123, 166, 89, 23);
            frmPanelDeGestin.getContentPane().add(btnBaja);
           
            JButton btnModificacion = new JButton("Modificacion");
            btnModificacion.addActionListener(new ActionListener() {
                  public void actionPerformed(ActionEvent arg0) {
                        modificar();
                  }
            });
            btnModificacion.setFont(new Font("Tahoma", Font.BOLD, 12));
            btnModificacion.setBounds(229, 165, 116, 23);
            frmPanelDeGestin.getContentPane().add(btnModificacion);
           
            JButton btnLimpiar = new JButton("Limpiar");
            btnLimpiar.addActionListener(new ActionListener() {
                  public void actionPerformed(ActionEvent e) {
                        limpiar();
                  }
            });
            btnLimpiar.setFont(new Font("Tahoma", Font.BOLD, 12));
            btnLimpiar.setBounds(362, 166, 89, 23);
            frmPanelDeGestin.getContentPane().add(btnLimpiar);
           
            conectar();
      } // Fin initialize
     
      /**
       * Inicia la conexi�n con la base de datos
       */
      private void conectar(){
            // ILERNA: crear la conexi�n a la base de datos
    	  sessionFactory = SessionFactoryUtil.getSessionFactory();
      }
     
      /**
       * Libera los recursos de la conexion
       */
      private void desconectar(){
    	    // ILERNA: Cerrar la conexi�n a la base de datos
    	  sessionFactory.close();
          sessionFactory = null;
      }
     
      /**
       * Sale de la aplicaci�n
       */
      private void salir(){
    	   // ILERNA: Terminar la aplicaci�n
    	  if(sessionFactory != null){
              desconectar();
         }
      }
     
      /**
       * Deja en blanco los campos de texto
       */
      private void limpiar(){
            this.txtDepartamento.setText("");
            this.txtLocalidad.setText("");
            this.txtNombre.setText("");
      } // Fin limpiar
     
      private void alta(){
            if (isVacio(txtDepartamento)){
                  JOptionPane.showMessageDialog(null, "El n�mero de departamento no puede estar vac�o");
            }
            else{
                    
                  if (!isDepto((byte)Integer.parseInt(this.txtDepartamento.getText()))){
                        
                	  // ILERNA: Dar de alta registrando a un nuevo departamento en la tabla DEPARTAMENTOS
                	    session = sessionFactory.openSession();
                        tx = session.beginTransaction();
                        d.setDeptNo((byte)Integer.parseInt(this.txtDepartamento.getText()));
                        d.setDnombre(this.txtNombre.getText());
                        d.setLugar(this.txtLocalidad.getText());
                        session.save(d);
                        tx.commit();
                        session.close(); 
                        JOptionPane.showMessageDialog(null, "Inserci�n correcta");
                  }
                  else{
                        JOptionPane.showMessageDialog(null, "El n�mero de departamento ya existe");
                  }
            }
      } // Fin alta
     
      /**
       * Borro los campos de la tabla que coincidan con los criterios de b�squeda
       */
      private void baja(){
            // Si todos los campos est�n vacios muestro mensaje de error
            if (isVacio(txtDepartamento) && isVacio(this.txtLocalidad) && isVacio(this.txtNombre)){
                  JOptionPane.showMessageDialog(null, "No puedes dejar todos los campos vac�os");
            }
            else{
                  String consulta = "FROM Departamentos where ";
                  boolean banderaModificado = false;
                  if (!isVacio(this.txtDepartamento)){
                        if (banderaModificado){
                             consulta = consulta + " and dept_no = " + (byte)Integer.parseInt(this.txtDepartamento.getText());
                        }
                        else{
                             consulta = consulta + " dept_no = " + (byte)Integer.parseInt(this.txtDepartamento.getText());
                             banderaModificado = true;
                        }
                  } // Si departamento vacio
                 
                  if (!isVacio(this.txtLocalidad)){
                        if (banderaModificado){
                             consulta = consulta + " and lugar = " + this.txtLocalidad.getText();
                        }
                        else{
                             consulta = consulta + " lugar = " + this.txtLocalidad.getText();
                             banderaModificado = true;
                        }
                  } // Si localidad vacia
                 
                  if (!isVacio(this.txtNombre)){
                        if (banderaModificado){
                             consulta = consulta + " and dnombre = " + this.txtNombre.getText();
                        }
                        else{
                             consulta = consulta + " dnombre = " + this.txtNombre.getText();
                             banderaModificado = true;
                        }
                  } // Si nombre vac�o
                 
                  // ILERNA: abrir sesi�n, realizar petici�n de baja y eliminar entrada de la base de datos
                  // Utiliza la String "consulta"
                  session = sessionFactory.openSession();              	  
                  tx = session.beginTransaction();                      
                  Query query = session.createQuery(consulta);
                  List<Departamentos> departamentos = query.list();
                  Iterator<Departamentos> iter = departamentos.iterator();                     
                  while(iter.hasNext()){
                        d = iter.next();
                        session.delete(d);
                   }                     
                   tx.commit();
                  
                 
                  // ILERNA: Informar del n�mero de registros borrados
                  // Ejemplo: JOptionPane.showMessageDialog(null, "Se han borrado " + ............ + " registros");
                  JOptionPane.showMessageDialog(null, "Se han borrado " + departamentos.size() + " registros");
                  
                  // ILERNA: cerrar sesion
                  session.close();
                  
                  banderaModificado = false; // Reinicio bandera para proximas consultas
                 
            } // Fin else todos los campos vac�os
      } // Fin baja
     
      /**
       * Actualiza un registro de tabla indicando su n�mero de departamento.
       */
      private void modificar(){
            if (isVacio(txtDepartamento)){
                  JOptionPane.showMessageDialog(null, "El n�mero de departamento no puede estar vac�o");
            }
            else{
                  if (isDepto((byte)Integer.parseInt(this.txtDepartamento.getText()))){
                	    // ILERNA: Abrir sesi�n
                	    Query query;
                        int resultado; // Devuelve filas afectadas
                        session = sessionFactory.openSession();
                        
                        tx = session.beginTransaction();
                      
                        if (isVacio(this.txtLocalidad) && isVacio(this.txtNombre)){
                             JOptionPane.showMessageDialog(null, "Pues no vas a cambiar n� si no pones n� pa cambiar");
                        }
                        else if (isVacio(this.txtLocalidad)){
                        	// ILERNA:  actualizar la localidad
                        	query = session.createQuery("update Departamentos set dnombre = :dnombre" + " where dept_no = :dept_no");
                            query.setParameter("dnombre", this.txtNombre.getText());
                            query.setParameter("dept_no", (byte)Integer.parseInt(this.txtDepartamento.getText()));
                            resultado = query.executeUpdate();
                            JOptionPane.showMessageDialog(null, "Modificados " + resultado + " registros");
                        }
                        else if (isVacio(this.txtNombre)){
                        	// ILERNA:  actualizar el nombre de departamento
                        	 query = session.createQuery("update Departamentos set lugar = :lugar" + " where dept_no = :dept_no");
                             query.setParameter("lugar", this.txtLocalidad.getText());
                             query.setParameter("dept_no", (byte)Integer.parseInt(this.txtDepartamento.getText()));
                             resultado = query.executeUpdate();
                             JOptionPane.showMessageDialog(null, "Modificados " + resultado + " registros");
                        }
                        else{
                        	// ILERNA:  actualizar la localidad y el nombre de departamento
                             query = session.createQuery("update Departamentos set dnombre = :dnombre, lugar = :lugar" + " where dept_no = :dept_no");
                             query.setParameter("dnombre", this.txtNombre.getText());
                             query.setParameter("lugar", this.txtLocalidad.getText());
                             query.setParameter("dept_no", (byte)Integer.parseInt(this.txtDepartamento.getText()));
                             resultado = query.executeUpdate();
                             JOptionPane.showMessageDialog(null, "Modificados " + resultado + " registros");
                        }
                        tx.commit();
                        session.close();
                  }
                  else{
                        JOptionPane.showMessageDialog(null, "El c�digo no pertenece a ning�n registro");
                  }
            }
      } // Fin modificar
     
     
      /**
       * Devuelve TRUE si el departamento existe y false si no
       */
      private boolean isDepto(byte b){
    	    // ILERNA: Abrir sesi�n y comprobar si departamento existe
             session = sessionFactory.openSession();
             Query query = session.createQuery("FROM Departamentos where dept_no = " + b);
             List<Departamentos> departamentos = query.list();
             if (departamentos.isEmpty())
                  return false;
             else
                  return true;        
    	  
      } // Fin isAlta
     
      /**
       * Devuelve TRUE si el textArea est� vacio, y false si tiene contenido
       * @param t es JTextField a analizar
       * @return
       */
      private boolean isVacio(JTextField t){
            return t.getText().equals("");
      } // Fin isVacio
} // Fin EjercicioHibernate