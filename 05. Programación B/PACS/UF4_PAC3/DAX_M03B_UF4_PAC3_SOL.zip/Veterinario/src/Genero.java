
public enum Genero {
	macho, hembra
}
