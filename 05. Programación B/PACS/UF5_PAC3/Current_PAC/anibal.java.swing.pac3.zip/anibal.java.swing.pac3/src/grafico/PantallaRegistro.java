package anibal.java.swing.pac1;

import javax.swing.JPanel;

public class PantallaRegistro extends JPanel {
	Ventana escuchador;
	public PantallaRegistro(Ventana escuchador) {
		this.escuchador = escuchador;
	}

}
