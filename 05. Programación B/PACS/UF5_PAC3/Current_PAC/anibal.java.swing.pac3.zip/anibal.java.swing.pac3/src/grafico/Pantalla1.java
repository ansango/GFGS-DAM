package anibal.java.swing.pac1;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class Pantalla1 extends JPanel{
	
	JLabel textoBienvenida;
	
	public Pantalla1(String texto) {
		textoBienvenida = new JLabel(texto);
	}
		
}
