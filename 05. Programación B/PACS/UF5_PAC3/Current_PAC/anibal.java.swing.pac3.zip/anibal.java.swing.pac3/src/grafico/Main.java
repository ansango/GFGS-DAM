
package anibal.java.swing.pac1;

public class Main /*implements ActionListener*/{


	public static void main(String[] args) {
		
		VentanaDefinitiva v = new VentanaDefinitiva();
		
	}


}
